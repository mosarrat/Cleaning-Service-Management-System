-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: May 27, 2021 at 03:16 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cleaning`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Id` int(11) NOT NULL,
  `Full_Name` varchar(100) NOT NULL,
  `User_Name` varchar(100) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Image_Name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Id`, `Full_Name`, `User_Name`, `Email`, `Password`, `Image_Name`) VALUES
(20, 'Mosarrat Kabir', 'MSK', 'msk@gmail.com', '4321', 'Service_Category_357.jpeg'),
(21, 'Karishma Naaz', 'SKN', 'skn@gmail.com', '1234', 'Service_Category_373.jpeg'),
(22, 'Sk.Azmiara', 'SKA', 'ska@gmail.com', '0987', 'Service_Category_470.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(10) NOT NULL,
  `service` varchar(150) NOT NULL,
  `price` decimal(20,0) NOT NULL,
  `price_des` varchar(100) NOT NULL,
  `appointment_on` datetime NOT NULL,
  `measure` varchar(50) NOT NULL,
  `total` decimal(20,0) NOT NULL,
  `appointment_made` datetime NOT NULL,
  `status` varchar(50) NOT NULL,
  `customer_name` varchar(150) NOT NULL,
  `customer_contact` varchar(20) NOT NULL,
  `customer_email` varchar(150) NOT NULL,
  `customer_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `service`, `price`, `price_des`, `appointment_on`, `measure`, `total`, `appointment_made`, `status`, `customer_name`, `customer_contact`, `customer_email`, `customer_address`) VALUES
(5, 'Office Cleaning And Pest Control', '6', '/sq.ft.', '2021-04-25 08:00:00', '3000', '18000', '2021-04-23 04:15:11', 'Completed', 'Tahmid', '0198234756', 'tahmidkabir5@gmail.com', 'House no-51, Road no-1, Block-G, Aftabnagar'),
(6, 'Dry Cleaning', '70', 'Each', '2021-04-25 12:30:00', '5', '350', '2021-04-23 04:25:49', 'Completed', 'Karishma', '01456537467', 'karishma@gmail.com', 'Puran Dhaka'),
(7, 'Car Wash', '7000', 'Each', '2021-05-08 10:00:00', '1', '7000', '2021-04-23 04:53:03', 'Completed', 'Mahadia', '01987654321', 'mahadiakabir@gmail.com', 'Gulshan'),
(8, 'Laundry Wash', '20', 'Each', '2021-05-06 16:30:00', '10', '200', '2021-04-24 08:05:54', 'Completed', 'Azmiara', '01543298765', 'azmiara@gmail.com', 'House-21,Block-G,Basundhara'),
(9, 'Pest Control', '3', '/sq.ft.', '2021-05-22 10:00:00', '2000', '6000', '2021-04-24 02:03:15', 'Completed', 'Kabir', '01897654321', 'mgkt@gmail.com', 'Mohanagar.'),
(10, 'House Cleaning', '2', '/sq.ft.', '2021-05-04 10:00:00', '3000', '6000', '2021-05-01 05:57:07', 'Appoint', 'Filith', '01897654321', 'filith@gmail.com', '2/B Rampura, Dhaka'),
(12, 'Pest Control', '3', '/sq.ft.', '2021-05-29 13:30:00', '1000', '3000', '2021-05-26 05:27:47', 'Appoint', 'Mosarrat', '01987654321', 'msk@gmail.com', 'House no-51, Road no-1, Block-G, Aftabnagar');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `Id` int(10) NOT NULL,
  `Title` varchar(100) NOT NULL,
  `Image_Name` varchar(255) NOT NULL,
  `Active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`Id`, `Title`, `Image_Name`, `Active`) VALUES
(7, 'Home', 'Service_Category_235.jpg', 'Yes'),
(8, 'Office', 'Service_Category_96.jpg', 'Yes'),
(9, 'Laundry', 'Service_Category_474.jpg', 'Yes'),
(10, 'Car', 'Service_Category_250.png', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `Id` int(10) NOT NULL,
  `Title` varchar(150) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Price` decimal(10,0) NOT NULL,
  `Price_des` varchar(20) NOT NULL,
  `Image_Name` varchar(255) NOT NULL,
  `Category_Title` varchar(100) NOT NULL,
  `Active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`Id`, `Title`, `Description`, `Price`, `Price_des`, `Image_Name`, `Category_Title`, `Active`) VALUES
(3, 'House Cleaning And Pest Control', 'Dusting, Booming, Pest Control & Disinfecting', '5', '/sq.ft.', 'Service_Category_540.jpg', 'Home', 'Yes'),
(5, 'Office Cleaning And Pest Control', 'Dusting,Glass ceaning,Pest control & Disinfecting', '6', '/sq.ft.', 'Service_Category_45.jpg', 'Office', 'Yes'),
(6, 'Car Wash', 'Inside And Outside Car Cleaning', '7000', 'Each', 'Service_Category_975.png', 'Car', 'Yes'),
(7, 'Dry Cleaning', 'Dry Cleaning Only', '70', 'Each', 'Service_Category_52.jpg', 'Laundry', 'Yes'),
(10, 'Pest Control', 'Pest Control & Disinfecting', '3', '/sq.ft.', 'Service_Category_700.jpg', 'Home ', 'Yes'),
(11, 'Laundry Wash', 'Machine Wash with Fabric & Color Guard', '20', 'Each', 'Service_Category_412.jpg', 'Laundry', 'Yes'),
(12, 'Laundry Iron', 'Iron & Fold Laundry', '10', 'Each', 'Service_Category_169.jpg', 'Laundry', 'Yes'),
(13, 'Wash & Iron', 'Machine Wash,Iron & Fold Laundry', '30', 'Each', 'Service_Category_128.jpg', 'Laundry', 'Yes'),
(14, 'House Cleaning', 'Dusting, Booming & Disinfecting', '2', '/sq.ft.', 'Service_Category_135.jpg', 'Home', 'Yes'),
(15, 'Office Cleaning', 'Dusting,Brooming,Glass cleaning & Disinfecting', '4', '/sq.ft.', 'Service_Category_492.jpg', 'Office', 'Yes'),
(16, 'Pest Control', 'Pest Control & Disinfecting', '3', '/sq.ft.', 'Service_Category_239.jpg', 'Office', 'No');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
